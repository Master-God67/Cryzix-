package com.cryzix.rp

import android.app.Activity
import android.os.Bundle
import android.graphics.*
import android.view.*
import android.widget.*
import java.net.*
import java.io.*
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread
import kotlin.math.*

class MainActivity : Activity() {
    private lateinit var game: GameView
    private lateinit var status: TextView
    private var server: ServerSocket? = null
    private var socket: Socket? = null
    private var running = AtomicBoolean(false)
    private val peers = mutableMapOf<String, PointF>()
    private val playerId = "P" + (100..999).random()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(16,24,32)) }
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(12,8,12,8) }
        status = TextView(this).apply { text = "CRYZIX RP  •  SOLO MODE"; setTextColor(Color.WHITE); textSize=14f }
        bar.addView(status, LinearLayout.LayoutParams(0,48,1f))
        val host = Button(this).apply { text="HOST Wi-Fi"; setOnClickListener { hostWifi() } }
        val join = Button(this).apply { text="JOIN IP"; setOnClickListener { joinDialog() } }
        bar.addView(host); bar.addView(join)
        root.addView(bar)
        game = GameView()
        root.addView(game, LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root)
    }

    private fun hostWifi() {
        if (running.get()) return
        thread {
            try {
                server = ServerSocket(7777); running.set(true)
                runOnUiThread { status.text = "HOSTING • Port 7777 • Share hotspot IP" }
                while (running.get()) {
                    val client = server!!.accept()
                    if (peers.size >= 3) { client.close(); continue }
                    thread { handleClient(client) }
                }
            } catch (_: Exception) { runOnUiThread { status.text = "Host stopped" } }
        }
    }

    private fun joinDialog() {
        val input = EditText(this).apply { hint="Host IP (e.g. 192.168.43.1)" }
        AlertDialog.Builder(this).setTitle("Join Wi-Fi Hotspot").setMessage("Connect both phones to the same hotspot, then enter the host phone's local IP.")
            .setView(input).setPositiveButton("JOIN") { _,_ -> joinWifi(input.text.toString().trim()) }
            .setNegativeButton("CANCEL",null).show()
    }

    private fun joinWifi(ip: String) {
        thread {
            try {
                socket = Socket(); socket!!.connect(InetSocketAddress(ip,7777),5000)
                running.set(true); runOnUiThread { status.text = "CONNECTED • Wi-Fi multiplayer" }
                val out = PrintWriter(socket!!.getOutputStream(),true)
                val reader = BufferedReader(InputStreamReader(socket!!.getInputStream()))
                while (running.get()) {
                    out.println("$playerId,${game.playerX},${game.playerY}")
                    val line = reader.readLine() ?: break
                    parsePeers(line)
                    Thread.sleep(80)
                }
            } catch (e: Exception) { runOnUiThread { status.text = "Could not connect • Check IP/hotspot" } }
        }
    }

    private fun handleClient(client: Socket) {
        try {
            val reader = BufferedReader(InputStreamReader(client.getInputStream()))
            val out = PrintWriter(client.getOutputStream(),true)
            while (running.get() && !client.isClosed) {
                val line = reader.readLine() ?: break
                val p = line.split(",")
                if (p.size == 3) synchronized(peers) { peers[p[0]]=PointF(p[1].toFloatOrNull()?:0f,p[2].toFloatOrNull()?:0f) }
                val snapshot = synchronized(peers) { peers.entries.joinToString(";") { "${it.key},${it.value.x},${it.value.y}" } }
                out.println(snapshot)
            }
        } catch (_: Exception) { } finally { try { client.close() } catch (_:Exception){} }
    }

    private fun parsePeers(line:String) {
        synchronized(peers) {
            peers.clear()
            line.split(";").forEach { val p=it.split(","); if(p.size==3) peers[p[0]]=PointF(p[1].toFloatOrNull()?:0f,p[2].toFloatOrNull()?:0f) }
        }
    }

    override fun onDestroy() { running.set(false); try { server?.close(); socket?.close() } catch (_:Exception){}; super.onDestroy() }

    inner class GameView : View(this) {
        private val paint=Paint(Paint.ANTI_ALIAS_FLAG)
        var playerX=0f; var playerY=0f
        private var touchX=0f; private var touchY=0f
        private var moving=false
        private val buildings = listOf(RectF(100f,80f,300f,210f),RectF(420f,70f,650f,230f),RectF(760f,90f,960f,220f),
            RectF(130f,360f,340f,510f),RectF(470f,350f,690f,520f),RectF(820f,360f,1040f,510f))
        override fun onDraw(c:Canvas) {
            super.onDraw(c); val sx=width/1200f; val sy=height/650f
            c.save(); c.scale(sx,sy)
            c.drawColor(Color.rgb(87,130,93))
            paint.color=Color.rgb(65,69,72); c.drawRect(0f,270f,1200f,335f,paint); c.drawRect(350f,0f,410f,650f,paint)
            paint.color=Color.WHITE; paint.strokeWidth=3f
            for(x in 0..1200 step 90) c.drawLine(x.toFloat(),300f,x+42f,300f,paint)
            for(y in 0..650 step 90) c.drawLine(380f,y.toFloat(),380f,y+42f,paint)
            buildings.forEachIndexed { i,r ->
                paint.color=Color.rgb(45,55,66); c.drawRoundRect(r,12f,12f,paint)
                paint.color=Color.rgb(105,119,130); c.drawRoundRect(r.left+12,r.top+12,r.right-12,r.bottom-12,8f,8f,paint)
                paint.color=Color.WHITE; paint.textSize=20f
                c.drawText(listOf("POLICE","HOSPITAL","CITY HALL","GARAGE","MARKET","APARTMENTS")[i],r.left+18,r.top+38,paint)
            }
            if(playerX==0f && playerY==0f){playerX=600f;playerY=300f}
            synchronized(peers){ peers.forEach { (id,p)-> paint.color=Color.YELLOW; c.drawCircle(p.x,p.y,17f,paint); paint.color=Color.BLACK; paint.textSize=14f;c.drawText(id,p.x-15,p.y-24,paint) } }
            paint.color=Color.rgb(25,195,125); c.drawCircle(playerX,playerY,19f,paint)
            paint.color=Color.WHITE; paint.textSize=16f;c.drawText("YOU",playerX-15,playerY-28,paint)
            paint.color=Color.argb(110,0,0,0); c.drawCircle(1050f,535f,75f,paint)
            paint.color=Color.WHITE;c.drawCircle(1050f,535f,7f,paint)
            paint.textSize=18f;c.drawText("DRAG TO MOVE",30f,620f,paint)
            c.restore(); postInvalidateDelayed(33)
        }
        override fun onTouchEvent(e:MotionEvent):Boolean {
            val x=e.x/(width/1200f); val y=e.y/(height/650f)
            when(e.action) {
                MotionEvent.ACTION_DOWN,MotionEvent.ACTION_MOVE -> {
                    if(x>930f && y>420f) { val dx=x-1050f; val dy=y-535f; val len=max(1f,sqrt(dx*dx+dy*dy)); playerX+=(dx/len)*5f; playerY+=(dy/len)*5f }
                    else { touchX=x; touchY=y; val dx=x-playerX; val dy=y-playerY; val len=max(1f,sqrt(dx*dx+dy*dy)); playerX+=(dx/len)*5f; playerY+=(dy/len)*5f }
                    playerX=playerX.coerceIn(25f,1175f);playerY=playerY.coerceIn(25f,625f); invalidate(); return true
                }
            }
            return true
        }
    }
}
